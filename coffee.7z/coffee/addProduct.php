<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['p_id'] = 'P101';
// $_POST['productname'] = '拿鐵';
// $_POST['pic_id'] = '000';
// $_POST['p_price'] = '100';



if (isset($_POST['p_id']) && isset($_POST['productname']) && isset($_POST['pic_id']) && isset($_POST['p_price'])){
	if ($db->dbConnect()) {
        if ($db->addproduct("product",$_POST['p_id'] ,$_POST['productname'], $_POST['pic_id'] ,$_POST['p_price'])) {
            // $product = true;
            echo "true";
        } else echo "false";//$product = false;
    } else echo "false";//$product = false;
}else echo "false";//$product = false;

// echo $product;
// return $product;

?>