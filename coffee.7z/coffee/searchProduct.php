<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['p_id'] = 'P010';
if (isset($_POST['p_id'])){
	if ($db->dbConnect()) {
        echo $db->searchproduct("product", $_POST['p_id']);
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>