<?php
require "DataBase.php";
$db = new DataBase();

// addOrderrecord(c_id,o_id, totalcups , discount, totalprice,firstproduct) 
// $_POST['c_id'] = 'C00000007';
// $_POST['totalcups'] = '2';
// $_POST['discount'] = "";
// $_POST['totalprice'] = '200';
// $_POST['firstproduct'] = '美式';

if (isset($_POST['c_id']) && isset($_POST['totalcups']) && isset($_POST['discount']) && isset($_POST['totalprice']) && isset($_POST['firstproduct'])){
	if ($db->dbConnect()) {
        $id = $db->autoEnCode("order_id");
        if ($db->addorderrecord("orderrecorred",$_POST['c_id'] ,$id, $_POST['totalcups'] ,$_POST['discount'] ,$_POST['totalprice'] ,$_POST['firstproduct'])) {
            echo "true"."," . $id ;
        } else echo "false";
    } else echo "false";
}else echo "false";
?>