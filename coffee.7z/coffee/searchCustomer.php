<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000004';

if (isset($_POST['c_id'])){
	if ($db->dbConnect()) {
        echo $db->searchcustomer("customer_product", $_POST['c_id']);
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>