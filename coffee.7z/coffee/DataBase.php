<?php
require "DataBaseConfig.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    //----- register table -----//

    //--- 檢查id
    function checkID($table,$columnname,$email)
    {
        $Email = $this->prepareData($email);

        $this->sql = "select " . $columnname ." from " . $table . " where not exists(select '". $columnname ."' from ". $table ." where ". $table .".". $columnname ." = '" . $Email . "');";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        //$row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) { $check = true;} 
        else $check = false;
        return $check;
    }

    //--- 取得customer id
    function autoEnCode($type)
    {
        try{
        $this->sql = "select *  from autoencode where code_type = '" . $type ."'";
        $result = mysqli_query($this->connect, $this->sql);
        $row_count = mysqli_fetch_assoc($result);
        if(mysqli_num_rows($result) != 0){
            $max = $row_count['code_max'];//最大長度
            $count = $row_count['code_count']+1;//目前的流水號
            $head = $row_count['code_head'];//檔頭
            
            $value = str_pad($count,$max-strlen($head),'0',STR_PAD_LEFT);//補零
            $value = $head.$value;
            //回存編號
            $this->sql1 = "update autoencode set code_count = " . $count . " where code_type = '" . $type . "'";
            
            if (mysqli_query($this->connect, $this->sql1)) {return $value;} else return false;
        }
        }catch(Exception $e){throw $e;}
    }

    //--- 新增
    function signUp($table,$c_ID,$name,$phone,$email,$password,$nickname,$gender,$birthday,$bluetooth,$allergen)
    {
        $CID = $this->prepareData($c_ID);
        $Name = $this->prepareData($name);
        $Phone = $this->prepareData($phone);
        $Email = $this->prepareData($email);
        $Bluetooth = $this->prepareData($bluetooth);
        $password = $this->prepareData($password);
        $Nickname = $this->prepareData($nickname);
        $Gender = $this->prepareData($gender);
        $Birthday = $this->prepareData($birthday);
        $Allergen = $this->prepareData($allergen);
        $password = password_hash($password, PASSWORD_DEFAULT);
        
        if($Allergen != "" || $Allergen != " "){$this->sql = "INSERT INTO " . $table . "(C_ID, name, phone, email, bluetooth, password, nickname, gender, birthday, allergen) VALUES ('" . $CID . "','" . $Name . "','" . $Phone . "','" . $Email . "','" . $Bluetooth . "','" . $password . "','" . $Nickname . "','" . $Gender . "','" . $Birthday . "','" . $Allergen . "')";}
        else{$this->sql = "INSERT INTO " . $table . "(C_ID, name, phone, email, bluetooth, password, nickname, gender, birthday) VALUES ('" . $CID . "','" . $Name . "','" . $Phone . "','" . $Email . "','" . $Bluetooth . "','" . $password . "','" . $Nickname . "','" . $Gender . "','" . $Birthday ."')";}
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
     //--- login
    function logIn($table, $email, $password)
    {
        $email = $this->prepareData($email);
        $password = $this->prepareData($password);
        $this->sql = "select * from " . $table . " where email = '" . $email . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $dbc_id = $row['C_ID'];
            $dbemail = $row['email'];
            $dbpassword = $row['password'];
            if ($dbemail == $email && password_verify($password, $dbpassword)) {
                $login = true;
                
            } else $login = false;
        } else $login = false;
 
        return array($login,$dbc_id);
    }
    //--- 修正
    function editID($table,$c_id,$columnname, $email)
    {
        $Email = $this->prepareData($email);
        $CID = $this->prepareData($c_id);

        $this->sql = "select " . $columnname ." from " . $table . " where C_ID = '" . $CID ."';";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        $row = mysqli_fetch_assoc($result);//mysqli_fetch_assoc 返回關聯數組(那一行)
        if (mysqli_num_rows($result) != 0) {
            $dbemail = $row[$columnname];
            if ($dbemail != $Email) {
                $login = true;
            } else $login = false;
        } else $login = false;
        return $login;
        // 釋放記憶體
        mysqli_free_result($result);
    }
    function editpersonal($table,$c_ID,$name,$phone,$email,$password,$nickname,$gender,$birthday,$bluetooth,$allergen)
    {
        $CID = $this->prepareData($c_ID);
        $Name = $this->prepareData($name);
        $Phone = $this->prepareData($phone);
        $Email = $this->prepareData($email);
        $Bluetooth = $this->prepareData($bluetooth);
        $password = $this->prepareData($password);
        $Nickname = $this->prepareData($nickname);
        $Gender = $this->prepareData($gender);
        $Birthday = $this->prepareData($birthday);
        $Allergen = $this->prepareData($allergen);
        $password = password_hash($password, PASSWORD_DEFAULT);
        
        $this->sql = "UPDATE " . $table . " SET name = '" . $Name . "',  phone = '" . $Phone . "', email = '" . $Email . "', bluetooth = '" . $Bluetooth . "', password = '" . $password . "', nickname = '" . $Nickname . "', gender = '" . $Gender . "', birthday = '" . $Birthday . "', allergen = '" . $Allergen . "' WHERE C_ID = '" . $CID . "'";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    //--- 查詢
    function searchsignUp($table,$c_ID)
    {
        $CID = $this->prepareData($c_ID);

        $this->sql = "select * from " . $table . " where C_ID = '" . $CID . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)        
        if (mysqli_num_rows($result) != 0) {
        //    foreach($row as $search)
        //    {$new_array[] = urlencode($search);}
        //    return urldecode(json_encode($new_array));
            foreach($row as $search){$new_array[] = $search;}
            $output=implode(",",$new_array);
            return $output;
        } else return $search = false;
    }
    //--- 刪除
    function deletePersonal($table,$c_ID)
    {
        $CID = $this->prepareData($c_ID);

        $this->sql = "DELETE FROM " . $table . " where C_ID = '" . $CID . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        //if ($conn->query($sql) === TRUE)
        // $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)        
        if ($result == true) {return true;} else return false;
    }

    //--- 取得藍芽
    function getblue($table, $bluetooth)//回傳true/false給login.php
    {
        $bluetooth = $this->prepareData($bluetooth);

        $this->sql = "select * from " . $table . " where bluetooth = '" . $bluetooth . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        $row = mysqli_fetch_assoc($result);//mysqli_fetch_assoc 返回關聯數組(那一行)
        if (mysqli_num_rows($result) != 0) {
            $dbbluetooth = $row['C_ID'];
        } else $dbbluetooth = 'false';
        return $dbbluetooth;
    }

    //----- 喜好table -----//
    //--- 新增
    function favor($table,$C_ID ,$favor, $sweet ,$preferred_time, $coldhot)
    {
        $CID = $this->prepareData($C_ID);
        $favor = $this->prepareData($favor);
        $sweet = $this->prepareData($sweet);
        $preferred_time = $this->prepareData($preferred_time);
        $coldhot = $this->prepareData($coldhot);
        
        $this->sql = "INSERT INTO " . $table . "(C_ID, favorite, sweet, preferred_time, coldhot) VALUES ('" . $CID . "','" . $favor . "','" . $sweet . "','" . $preferred_time . "','" . $coldhot . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    //--- 修正
    function editfavor($table,$C_ID ,$favor, $sweet ,$preferred_time, $coldhot)
    {
        $CID = $this->prepareData($C_ID);
        $favor = $this->prepareData($favor);
        $sweet = $this->prepareData($sweet);
        $preferred_time = $this->prepareData($preferred_time);
        $coldhot = $this->prepareData($coldhot);
        
        $this->sql = "UPDATE " . $table . " SET favorite = '" . $favor . "',  sweet = '" . $sweet . "', preferred_time = '" . $preferred_time . "', coldhot = '" . $coldhot . "' WHERE C_ID = '" . $CID . "'";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //----- 商品table  -----//
    //--- 新增
    function addproduct($table,$p_id ,$productname,$pic_id, $p_price)
    {
        $P_id = $this->prepareData($p_id);
        $Productname = $this->prepareData($productname);
        $Pic_id = $this->prepareData($pic_id);
        $P_price = $this->prepareData($p_price);
        
        $this->sql = "INSERT INTO " . $table . "(P_ID, productname, pic_id, p_price) VALUES ('" . $P_id . "','" . $Productname . "','" . $Pic_id . "','" . $P_price . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }
    //--- 查詢
    function searchproduct($table,$p_ID)
    {
        $PID = $this->prepareData($p_ID);

        $this->sql = "select * from " . $table . " where P_ID = '" . $PID . "'";
        // $this->sql = "select * from " . $table . ";";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        if (mysqli_num_rows($result) != 0) {
            for($i=0; $i<mysqli_num_rows($result); $i++){ 
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)
            // foreach($row as $search){$new_array[] = urlencode($search);}}
            // return urldecode(json_encode($new_array));
            foreach($row as $search){$new_array[] = $search;}}
            $output=implode(",",$new_array);
            return $output;
        } else return $search = false;
    }

    //----- 客製化table -----//
    //--- 新增
    function customerproduct($table, $CP_ID, $C_ID, $P_ID, $cp_name, $sweet, $coldhot)
    {
        $cp_id = $this->prepareData($CP_ID);
        $CID = $this->prepareData($C_ID);
        $p_id = $this->prepareData($P_ID);
        $CP_name = $this->prepareData($cp_name);
        $sweet = $this->prepareData($sweet);
        $coldhot = $this->prepareData($coldhot);
        
        $this->sql = "INSERT INTO " . $table . "(CP_ID, C_ID, P_ID, CP_name, sweet, coldhot) VALUES ('" . $cp_id . "','" . $CID . "','" . $p_id ."','" . $CP_name . "','" . $sweet .  "','" . $coldhot . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //--- 修正(品項能做修改嗎?還是?)
    function editcustomerproduct($table, $CP_ID, $C_ID, $P_ID, $cp_name, $sweet, $coldhot)
    {
        $cp_id = $this->prepareData($CP_ID);
        $CID = $this->prepareData($C_ID);
        $p_id = $this->prepareData($P_ID);
        $cp_name = $this->prepareData($cp_name);
        $sweet = $this->prepareData($sweet);
        $coldhot = $this->prepareData($coldhot);
        
        $this->sql = "UPDATE " . $table . " SET CP_name = '" . $cp_name . "',  sweet = '" . $sweet . "', coldhot = '" . $coldhot . "' WHERE C_ID = '" . $CID . "'";
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    //--- 查詢(全部查詢)
    function searchcustomer($table,$c_ID)
    {
        $PID = $this->prepareData($c_ID);

        $this->sql = "select * from " . $table . " where C_ID = '" . $c_ID . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        if (mysqli_num_rows($result) != 0) {
            for($i=0; $i<mysqli_num_rows($result); $i++){ 
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)
            foreach($row as $search){$new_array[] = $search;}}
            $output=implode(",",$new_array);
            return $output;
        } else return $search = false;
    }
    
    //--- 刪除
    function deleteCustomerProduct($table,$c_ID,$cp_ID)
    {
        $CID = $this->prepareData($c_ID);
        $cp_ID = $this->prepareData($cp_ID);

        $this->sql = "DELETE FROM " . $table . " where C_ID = '" . $CID . "' AND CP_ID = '" . $cp_ID . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        //if ($conn->query($sql) === TRUE)
        // $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)        
        if ($result == true) {return true;} else return false;
    }

    //----- 訂單table -----//
    //--- 新增
    function addorderrecord($table, $C_ID, $o_ID, $totalcups , $discount, $totalprice ,$firstproduct)
    {
        $CID = $this->prepareData($C_ID);
        $o_id = $this->prepareData($o_ID);
        $totalcups = $this->prepareData($totalcups);
        $discount = $this->prepareData($discount);
        $totalprice = $this->prepareData($totalprice);
        $firstproduct = $this->prepareData($firstproduct);
        
        if($discount == "" || $discount == " "){$this->sql = "INSERT INTO " . $table . "(O_ID, C_ID, totalcups, totalprice, firstproduct) VALUES ('" . $o_id . "','" . $CID . "','" . $totalcups . "','" . $totalprice . "','" . $firstproduct ."')";}
        else{$this->sql = "INSERT INTO " . $table . "(O_ID, C_ID, totalcups, discount, totalprice, firstproduct) VALUES ('" . $o_id . "','" . $CID . "','" . $totalcups ."','" . $discount . "','" . $totalprice . "','" . $firstproduct ."')";}
        if (mysqli_query($this->connect, $this->sql)) {
            return true;
        } else return false;
    }

    function addsaledetail($table, $o_id, $p_id, $cups, $price)
    {
        $o_id = $this->prepareData($o_id);
        $p_id = $this->prepareData($p_id);
        $cups = $this->prepareData($cups);
        $price = $this->prepareData($price);
        $pp = preg_split("//", $p_id);

        if(preg_match("/CP/i",$p_id)){ $name = $pp[3]; $sweet = $pp[5]; $coldhot = $pp[4];}
        else{ $name = $pp[2]; $sweet = $pp[4]; $coldhot = $pp[3];}

        // INSERT INTO `product_detail`(`O_ID`, `P_ID`, `sweet`, `coldhot`, `iotcoffee`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]')
        $this->sql = "INSERT INTO " . $table . "(O_ID, P_ID, cups, price) VALUES ('" . $o_id . "','" . $p_id . "','" . $cups ."','" . $price . "')"; 
        $this->sqlpd = "INSERT INTO product_detail(O_ID, P_ID, pcp_id, sweet, coldhot, iotcoffee) VALUES ('" . $o_id . "', '" . $p_id . "', '" . $name . "', '" . $sweet . "', '" . $coldhot . "', 0)";
        if (mysqli_query($this->connect, $this->sql) && mysqli_query($this->connect, $this->sqlpd)){
            return true;
        } else return false;
    }

    //--- 訂單查詢(全部查詢)
    function searchorder($table,$c_ID)
    {
        $c_ID = $this->prepareData($c_ID);

        $this->sql = "select * from " . $table . " where C_ID = '" . $c_ID . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        if (mysqli_num_rows($result) != 0) {
            for($i=0; $i<mysqli_num_rows($result); $i++){ 
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)
            foreach($row as $search){$new_array[] = $search;}}
            $output=implode(",",$new_array);
            return $output;
        } else return $search = false;
    }

    //--- 訂單明細查詢
    function searchsaledetail($c_ID, $o_ID)
    {
        $c_ID = $this->prepareData($c_ID);
        $o_ID = $this->prepareData($o_ID);

        // p_id(明細), cups(明細) , sweet(客製化), coldhot(客製化), price(明細), p_price(商品), pic_id(商品)

        $this->sql = "select * from saledetail where O_ID = '" . $o_ID . "'";// AND P_ID LIKE 'P%';
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        if (mysqli_num_rows($result) != 0) 
        {
            for($i=0; $i<mysqli_num_rows($result); $i++){ 
                $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
                $dbp_id = $row['P_ID'];
                if(preg_match("/CP/i",$dbp_id))
                {
                    $pp = preg_split("//", $dbp_id);
                    $pidd = $pp[3];

                    // find product id
                    if ($pidd =="0") { $pid = "P010"; }
                    elseif($pidd == "1"){$pid = "P110";}
                    $this ->sqlp = "select * from product where P_ID = '" . $pid ."'";
                    $resultp = mysqli_query($this->connect, $this->sqlp);
                    if (mysqli_num_rows($resultp) != 0) { 
                        $p = mysqli_fetch_array($resultp,MYSQLI_ASSOC);
                        $returna = $dbp_id . "," . $row['cups'] ."," . $pp[5] . "," . $pp[4] . "," . $row['price'] . "," . $p['p_price'] . "," . $p['pic_id']; 
                    }     
                }
                else
                {
                    $this ->sqlp = "select * from product where P_ID = '" . $dbp_id ."'";
                    $resultp = mysqli_query($this->connect, $this->sqlp);
                    if (mysqli_num_rows($resultp) != 0) { 
                        $p = mysqli_fetch_array($resultp,MYSQLI_ASSOC);
                        $returna = $dbp_id . "," . $row['cups'] .",0,1," . $row['price'] . "," . $p['p_price'] . "," . $p['pic_id']; 
                    }
                }
                $new_array[] = $returna;
            }
            // return urldecode(json_encode($new_array));
            $output=implode(",",$new_array);
            return $output;
        }
    }

    //algorithm
    function algorithm($table,$c_ID,$time)
    {
        $c_ID = $this->prepareData($c_ID);
        $time = $this->prepareData($time);

        // c_id,favorite, prefeered time,sweet, coldhot

        $this->sql = "select * from " . $table . " where C_ID = '" . $c_ID . "' and preferred_time = '" . $time . "'";
        $result = mysqli_query($this->connect, $this->sql);//mysqli_query 執行查詢
        if (mysqli_num_rows($result) != 0) {
            for($i=0; $i<mysqli_num_rows($result); $i++){ 
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);//mysqli_fetch_assoc 返回關聯數組(那一行)
            foreach($row as $search){$new_array[] = $search;}}
            $output=implode(",",$new_array);
            return $output;
        } else return $search = false;
    }

}

?>
