<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['cp_id'] = 'CP034';
// $_POST['c_id'] = 'C00000004';
// $_POST['p_id'] = 'P010';
// $_POST['cp_name'] = 'favor';
// $_POST['sweet'] = '4';
// $_POST['coldhot'] = '3';


if (isset($_POST['cp_id']) && isset($_POST['c_id']) && isset($_POST['p_id']) && isset($_POST['cp_name']) && isset($_POST['sweet'])  && isset($_POST['coldhot'])){
	if ($db->dbConnect()) {
        if ($db->customerproduct("customer_product",$_POST['cp_id'] ,$_POST['c_id'] ,$_POST['p_id'] ,$_POST['cp_name'] ,$_POST['sweet'] , $_POST['coldhot'])) {
            // $cp = true;
            echo "true";
        } else echo "false";//$cp = false;
    } else echo "false";//$cp = false;
}else echo "false";//$cp = false;

// echo $cp;
// return $cp;

?>