<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000002';


if (isset($_POST['c_id'])){
	if ($db->dbConnect()) {
        if ($db->deletePersonal("register",$_POST['c_id'] )) {
            echo "true";// $sign = true;
        } else echo "false";//$sign = false;
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>