<?php
//$_POST['email'] = 'jjjjj@gmail.com';
//$_POST['password'] = 'jjjjj';
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['email']) && isset($_POST['password'])) {
    if ($db->dbConnect()) {
        $result = $db->logIn("register", $_POST['email'], $_POST['password']);
        if ($result[0]) {
            echo "true"."," . $result[1] ;// $loginn = true;
            // echo $result[1];
        } else  echo "false";//$loginn = false;
    } else echo "false";//$loginn = false;
} else echo "false";//$loginn = false;
// echo $loginn;
// return $loginn;

?>