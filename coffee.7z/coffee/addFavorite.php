<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000003';
// $_POST['favor'] = '1';
// $_POST['sweet'] = '1';
// $_POST['preferred_time'] = '1';
// $_POST['coldhot'] = '1';


if (isset($_POST['c_id']) && isset($_POST['favor']) && isset($_POST['sweet']) && isset($_POST['preferred_time']) && isset($_POST['coldhot'])){
	if ($db->dbConnect()) {
        if ($db->favor("favorite",$_POST['c_id'] ,$_POST['favor'], $_POST['sweet'] ,$_POST['preferred_time'], $_POST['coldhot'])) {
            // $favor = true;
            echo "true";
        } else echo "false";//$favor = false;
    } else echo "false";//$favor = false;
}else echo "false";//$favor = false;

// echo $favor;
// return $favor;
?>