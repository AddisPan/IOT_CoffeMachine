<?php
// $_POST['bluetooth'] = 'jjjjjjjjjj';

require "DataBase.php";

$db = new DataBase();
if (isset($_POST['bluetooth'])) {
    if ($db->dbConnect()) {
        $blue = $db->getblue("register", $_POST['bluetooth']);
        echo $blue;
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>