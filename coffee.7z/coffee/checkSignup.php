<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['phone'] = '0999999228';
// $_POST['email'] = 'ncdn@gmail.com';
// $_POST['bluetooth'] = 'vfghfhgfk';

if(isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['bluetooth']))
{
	if($db->dbConnect()){
		// check phone
		if($db->checkID("register","phone", $_POST['phone'])) {$ans = "Y";} else $ans = "0";    
		// check phone
		if (filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){ // filter_var : 確認email格式
			if ($db->checkID("register","email", $_POST['email'])) {$ans2 = "Y";} else $ans2 = "1";
		}else echo "email 格式錯誤";
		// check bluetooth
		if($db->checkID("register","bluetooth", $_POST['bluetooth'])) {$ans3 = "Y";} else $ans3 = "2";
	}else echo "Error: Database connection";

	$check = "" .$ans. "". $ans2 ."" .$ans3."";

	echo $check;
	// return $check;

}



?>
