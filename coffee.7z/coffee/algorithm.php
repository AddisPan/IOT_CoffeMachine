<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000004';
// $_POST['time'] = '2';
//return c_id,favorite, prefeered time,sweet, coldhot

if (isset($_POST['c_id']) && isset($_POST['time'])){
	if ($db->dbConnect()) {
        echo $db->algorithm("favorite", $_POST['c_id'], $_POST['time']);
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>