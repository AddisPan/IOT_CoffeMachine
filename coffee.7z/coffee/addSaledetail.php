<?php
require "DataBase.php";
$db = new DataBase();

// addSaledetail(o_id, p_id, cups, price,iotcoffee)   
// $_POST['o_id'] = 'O00000002';
// $_POST['p_id'] = 'P110';
// $_POST['cups'] = '1';
// $_POST['price'] = '100';




if (isset($_POST['p_id']) && isset($_POST['o_id']) && isset($_POST['cups']) && isset($_POST['price'])){
	if ($db->dbConnect()) {
        if ($db->addsaledetail("saledetail",$_POST['o_id'] ,$_POST['p_id'], $_POST['cups'] ,$_POST['price'])) {
            // $product = true;
            echo "true";
        } else echo "false";//$product = false;
    } else echo "false";//$product = false;
}else echo "false";//$product = false;

// echo $product;
// return $product;

?>