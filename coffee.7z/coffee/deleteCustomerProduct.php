<?php
require "DataBase.php";
$db = new DataBase();

//--- 刪除單一還是全部?
// $_POST['c_id'] = 'C00000007';
// $_POST['cp_id'] = 'CP101';


if (isset($_POST['c_id'])){
	if ($db->dbConnect()) {
        if ($db->deleteCustomerProduct("customer_product",$_POST['c_id'],$_POST['cp_id'] )) {
            // $sign = true;
            echo "true";
        } else echo "false";//$sign = false;
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>