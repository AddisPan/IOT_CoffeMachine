<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000006';
// $_POST['name'] = 'jjjjj';
// $_POST['phone'] = '0999347698';
// $_POST['email'] = 'jjjjj@gmail.com';
// $_POST['password'] = 'jjjjj';
// $_POST['nickname'] = 'jjjjj';
// $_POST['gender'] = '0';
// $_POST['birthday'] = '2002/05/10';
// $_POST['bluetooth'] = 'jjjjjjjjjjjj';
// $_POST['allergen'] = '1';

if (isset($_POST['c_id']) && isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['nickname']) && isset($_POST['gender']) && isset($_POST['birthday']) && isset($_POST['bluetooth']) && isset($_POST['allergen'])){
	if ($db->dbConnect()) {
        if($db->editID("register",$_POST['c_id'],"phone",$_POST['phone'])){
		    if($db->checkID("register","phone", $_POST['phone'])) {$ans = "Y";} else $ans = "0";
        }$ans = "Y";
		if (filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){ // filter_var : 確認email格式
            if($db->editID("register",$_POST['c_id'],"email",$_POST['email'])){
                if ($db->checkID("register","email", $_POST['email'])) {$ans2 = "Y";} else $ans2 = "1";
            }$ans2 = "Y";
		}else echo "email 格式錯誤";
        if($db->editID("register",$_POST['c_id'],"bluetooth",$_POST['bluetooth'])){
            if($db->checkID("register","bluetooth", $_POST['bluetooth'])) {$ans3 = "Y";} else $ans3 = "2";
        }$ans3 = "Y";
        if($ans == "Y"&& $ans2 == "Y" && $ans3 == "Y")
        {
            if ($db->editpersonal ("register",$_POST['c_id'] ,$_POST['name'], $_POST['phone'] ,$_POST['email'], $_POST['password'], $_POST['nickname'] , $_POST['gender'] , $_POST['birthday'] ,$_POST['bluetooth'] ,$_POST['allergen'])) {
                echo "true";//$sign = true;
            } else echo "false";//$sign = false;
        }else
        {
            $check = "" .$ans. " ". $ans2 ." " .$ans3."";
            return $check;
        }
        
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>