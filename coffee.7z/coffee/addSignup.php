<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['c_id'] = 'C00000010';
// $_POST['name'] = 'jackk';
// $_POST['phone'] = '0999011308';
// $_POST['email'] = 'jackk@gmail.com';
// $_POST['password'] = 'jackk';
// $_POST['nickname'] = 'jackk';
// $_POST['gender'] = '1';
// $_POST['birthday'] = '2002/05/10';
// $_POST['bluetooth'] = 'jackk';
// $_POST['allergen'] = ' ';

if (isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['nickname']) && isset($_POST['gender']) && isset($_POST['birthday']) && isset($_POST['bluetooth']) && isset($_POST['allergen'])){
	if ($db->dbConnect()) {
        $id = $db->autoEnCode("customer_id");
        if ($db->signUp("register",$id ,$_POST['name'], $_POST['phone'] ,$_POST['email'], $_POST['password'], $_POST['nickname'] , $_POST['gender'] , $_POST['birthday'] ,$_POST['bluetooth'] ,$_POST['allergen'])) {
            echo "true";//$sign = true;
            // echo $id;
        } else echo "false";//$sign = false;
    } else echo "Error: Database connection";
}else echo "All fields are required";
// return $sign;
?>