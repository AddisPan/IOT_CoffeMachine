<?php
require "DataBase.php";
$db = new DataBase();

//$_POST['c_id'] = 'C00000004';

if (isset($_POST['c_id'])){
	if ($db->dbConnect()) {
        echo $db->searchorder("orderrecorred", $_POST['c_id']);
    } else echo "Error: Database connection";
}else echo "All fields are required";

// return $sign;
?>