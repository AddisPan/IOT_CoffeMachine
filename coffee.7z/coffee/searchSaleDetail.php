<?php
require "DataBase.php";
$db = new DataBase();

// p_id, cups , sweet, coldhot, price, p_price, pic_id
// $_POST['c_id'] = 'C00000007';
// $_POST['o_id'] = 'O00000002';

if (isset($_POST['c_id']) && isset($_POST['o_id'])){
	if ($db->dbConnect()) {
        echo $db->searchsaledetail($_POST['c_id'] , $_POST['o_id']);
    } else echo "Error: Database connection";
}else echo "All fields are required";

?>