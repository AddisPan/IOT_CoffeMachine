<?php
require "DataBase.php";
$db = new DataBase();

// $_POST['cp_id'] = 'CP001';
// $_POST['c_id'] = 'C00000007';
// $_POST['p_id'] = 'POO1';
// $_POST['cp_name'] = '爸';
// $_POST['sweet'] = '1';
// $_POST['coldhot'] = '1';


if (isset($_POST['cp_id']) && isset($_POST['c_id']) && isset($_POST['p_id']) && isset($_POST['cp_name']) && isset($_POST['sweet'])  && isset($_POST['coldhot'])){
	if ($db->dbConnect()) {
        if ($db->editcustomerproduct("customer_product",$_POST['cp_id'] ,$_POST['c_id'] ,$_POST['p_id'] ,$_POST['cp_name'] ,$_POST['sweet'] , $_POST['coldhot'])) {
            echo "true";// $cp = true;
        } else echo "false";//$cp = false;
    } else echo "false";//$cp = false;
}else echo "false";//$cp = false;
// return $cp;
?>